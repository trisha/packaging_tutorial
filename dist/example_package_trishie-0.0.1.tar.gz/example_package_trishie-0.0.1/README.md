# Example PyPi Package

This is a simple example package from the [tutorial](https://packaging.python.org/en/latest/tutorials/packaging-projects/) from [pypi](https://pypi.org/). You can use
[GitHub-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

- More info on .toml: https://packaging.python.org/en/latest/guides/writing-pyproject-toml/
